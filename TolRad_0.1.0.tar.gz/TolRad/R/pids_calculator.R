
## Package: TolRad

#' pids_calculator
#'
#' @param path path to genome annotation file with Pfam IDs (Cross-reference (Pfam) or Pfam) and Species name
#' @param organismID column with identifying name of each species
#' @param pfam_term Which type of Pfam is tha annotation, option; "ID" (exp. PF00001), "S1" (exp. "GPCR_A"), "S2" (exp. 7tm_1), or "Full" (exp. 7 transmembrane receptor (rhodopsin family
#' @param pfamID column with Pfam IDs associated with each gene, multiple Pfams allowd per cell if seperated with (;)
#' @param file_type input file type, "excel" for .excel files, "csv" for .csv files, and "tsv" for .tsv files and "tsv_eg" for the EggNogMapper tsv output with 4 skipped lines
#' @param geneID column with Gene IDs
#'
#' @return DF where each row is an organism
#'
#' @importFrom magrittr "%>%"
#' @import dplyr
#' @importFrom tidyr "pivot_wider"
#'
#' @export
#'
#' @examples
#'
#' pids_calculator(path = "test",
#'                organismID = "Organism",
#'                pfamID = "Pfam",
#'                pfam_term = "ID",
#'                file_type = "test",
#'                geneID = "Entry")

pids_calculator = function(path,
                           pfamID = "Pfam" ,
                           organismID = "Organism",
                           geneID = "Entry",
                           file_type = "excel",
                           pfam_term = "ID") {

  # read your data
  ifelse(file_type == "excel",
  df <- readxl::read_excel(path),
    ifelse(file_type == "csv",
           df <- readr::read_csv(path),
           ifelse(file_type == "tsv",
                  df <- readr::read_tsv(path),
                  ifelse(file_type == "tsv_eg",
                          df <- readr::read_tsv(path, col_names = TRUE, id="path", skip = 4, show_col_types = FALSE),
                         ifelse(file_type == "test",
                                df <- data.frame(geneID = c("O34162","P14611","P14697"),
                                                 organismID = c("Textus necator","Textus necator","Textus necator"),
                                                 pfamID = c("PF00300;PF07992;", "PF02803;PF03466;", "PF00106;")),
                          print("Only csv, excel and tsv are recognized"))))))

  names(df)[names(df) == pfamID] <- 'pfamID'
  names(df)[names(df) == geneID] <- 'geneID'
  names(df)[names(df) == organismID] <- 'organismID'

  # Calculate pfam percent in genome
   TolRad::pfam_perct(df, .data$pfamID, .data$organismID, .data$geneID) -> df_out

   df_out %>%
     tidyr::drop_na(organismID) ->   df_out

  # Select Model IDs and Run Model

   ifelse(pfam_term == "ID",
          dplyr::left_join(TolRad_Pfam, df_out, by = c("TolRad_ids" = "pfamID")) %>%
          dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
          tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
          ifelse(pfam_term == "S1",
                 dplyr::left_join(TolRad_Pfam, df_out, by = c("Short_name1" = "pfamID")) %>%
                 dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                 tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                 ifelse(pfam_term == "S2",
                        dplyr::left_join(TolRad_Pfam, df_out, by = c("Short_name2" = "pfamID")) %>%
                        dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                        tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                        ifelse(pfam_term == "Full",
                               dplyr::left_join(TolRad_Pfam, df_out, by = c("Full_name" = "pfamID")) %>%
                               dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                               tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                        print("Pfam Term Unknown")))))
   df_out
}
