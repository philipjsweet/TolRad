## Name: TolRad_manual
## Package: TolRad

#' TolRad_manual
#'
#' @param organismID column with identifying name of each species
#' @param pfam_term Which type of Pfam is tha annotation, option; "ID" (exp. PF00001), "S1" (exp. "GPCR_A"), "S2" (exp. 7tm_1), or "Full" (exp. 7 transmembrane receptor (rhodopsin family))
#' @param pfamID column with Pfam IDs associated with each gene, multiple Pfams allowd per cell if seperated with (;)
#' @param geneID column with Gene IDs
#' @param df DF with all PFAM annotations for a species of bacteria
#'
#' @importFrom magrittr "%>%"
#' @import caret
#' @importFrom stats "predict"
#' @import modelr
#' @importFrom modelr "add_predictions"
#'
#' @export
#'
#' @returns A single line dataframe with the organmism ID, predicted tolerance and zero counts
#'
#' @examples
#'  df <- data.frame(Organism = c("Textus necator","Textus necator","Textus necator"),
#'                   ID = c("ID","ID","ID"),
#'                   Pfam = c("PF00300;PF07992;", "PF02803;PF03466;", "PF00106;"),
#'                   Entry = c("O34162","P14611","P14697"))
#'
#'  TolRad::TolRad_manual(df)


TolRad_manual = function(df,  organismID = "Organism", pfamID = "Pfam", pfam_term = "ID", geneID = "Entry" ){

  # Calculate pfam percent in genome

  names(df)[names(df) == pfamID] <- 'pfamID'
  names(df)[names(df) == geneID] <- 'geneID'
  names(df)[names(df) == organismID] <- 'organismID'

  TolRad::pfam_perct(df, pfamID = pfamID, organismID = organismID, geneID = geneID) -> df_out

  # Select Model IDs and Run Model

  ifelse(pfam_term == "ID",
         dplyr::left_join(TolRad_Pfam, df_out, by = c("TolRad_ids" = "pfamID")) %>%
           dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
           tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
         ifelse(pfam_term == "S1",
                dplyr::left_join(TolRad_Pfam, df_out, by = c("Short_name1" = "pfamID")) %>%
                  dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                  tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                ifelse(pfam_term == "S2",
                       dplyr::left_join(TolRad_Pfam, df_out, by = c("Short_name2" = "pfamID")) %>%
                         dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                         tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                       ifelse(pfam_term == "Full",
                              dplyr::left_join(TolRad_Pfam, df_out, by = c("Full_name" = "pfamID")) %>%
                                dplyr::select(.data$organismID, .data$TolRad_ids, .data$p_id) %>%
                                tidyr::pivot_wider(names_from = .data$TolRad_ids, values_from = .data$p_id) -> df_out,
                              print("Pfam Term Unknown")))))
  df_out %>%
    tidyr::drop_na(organismID) ->   df_out

  ## Fill missing PFAM with zero
  df_out[is.na(df_out)] <- 0

  ## Run Model on each Organism
  df_out %>%
    dplyr::mutate(n_zero = rowSums(dplyr::across(tidyselect::vars_select_helpers$where(is.numeric)) == 0)) %>%
    modelr::add_predictions(model = TolRad_model, var = "TolRad_pred") %>%
    dplyr::mutate(Radiosensitive = ifelse(.data$TolRad_pred == 1, "Yes", "No")) %>%
    dplyr::select(.data$organismID, .data$Radiosensitive, .data$n_zero)

}
