
## Package: TolRad

#' TolRad_Predictor
#'
#' @param path path to genome annotation file with Pfam IDs (Cross-reference (Pfam) or Pfam) and Species name
#' @param organismID column with identifying name of each species. Default is "Organism"
#' @param pfam_term Which type of Pfam is tha annotation, option; "ID" (exp. PF00001), "S1" (exp. "GPCR_A"), "S2" (exp. 7tm_1), or "Full" (exp. 7 transmembrane receptor (rhodopsin family))
#' @param pfamID column with Pfam IDs associated with each gene, multiple Pfams allowed per cell if separated with (;). Default is "Pfam"
#' @param file_type input file type, "excel" for .excel files, "csv" for .csv files, and "tsv" for .tsv files and "tsv_eg" for the EggNogMapper tsv output with 4 skipped lines
#' @param geneID column with Gene IDs, default is "Entry"
#'
#' @return Dataframe with one species per row, Classification, Predictor abundance and Zero's.
#'
#' @importFrom magrittr "%>%"
#' @import caret
#' @importFrom stats "predict"
#' @import modelr
#' @importFrom modelr "add_predictions"
#' @export
#'
#' @examples
#' TolRad_Predict(path = "test",
#'                organismID = "Organism",
#'                pfamID = "Pfam",
#'                pfam_term = "ID",
#'                file_type = "test",
#'                geneID = "Entry")
#


## To Do: Add error message about no files found in source
## To Do: Add error message for columns not found

TolRad_Predict = function(path, organismID = "Organism", pfamID = "Pfam", pfam_term = "ID", file_type = "csv", geneID = "Entry" ){

  # Calculate relative abundance of each Pfam per genome
  dplyr::bind_rows(lapply(X = path, FUN = TolRad::pids_calculator, organismID = organismID , pfamID = pfamID, file_type = file_type, geneID = geneID, pfam_term = pfam_term)) -> output

  output %>%
  tidyr::drop_na(.data$organismID) -> output

  ## Fill missing PFAM with zero
  output[is.na(output)] <- 0

  ## Run Model on each Organism
    output %>%
     dplyr::mutate(n_zero = rowSums(dplyr::across(tidyselect::vars_select_helpers$where(is.numeric)) == 0)) %>%
     modelr::add_predictions(model = TolRad_model, var = "TolRad_pred") %>%
     dplyr::mutate(Radiosensitive = ifelse(.data$TolRad_pred == 1, "Yes", "No")) %>%
     dplyr::select(.data$organismID, .data$Radiosensitive, .data$n_zero)
}


