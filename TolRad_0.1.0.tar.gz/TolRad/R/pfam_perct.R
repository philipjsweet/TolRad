
## Name: pfam_perct
## Package: TolRad
## Inputs:
## Outputs:

#' pfam_perct
#'
#' @param df file with pfam ids
#' @param organismID column with identifying name of each species
#' @param pfamID column with Pfam IDs associated with each gene, multiple Pfams allowd per cell if seperated with (;)
#' @param geneID column with Gene IDs
#'
#' @return dataframe with pids
#'
#' @importFrom magrittr "%>%"
#' @importFrom tidyr "separate_rows"
#' @import dplyr
#'
#' @export
#'
#' @examples
#' x <- data.frame(pfamID= c("pfam1","pfam1;pfam3","pfam4"),
#'                  organismID = c("E.coli","E.coli","E.coli"),
#'                  geneID = c("GeneA","GeneB","GeneC")
#'         )
#' pfam_perct(df = x, pfamID = "pfamID", organismID = "organismID ", geneID = "geneID")
#'
pfam_perct <- function(df, pfamID = "pfamID" , organismID = "organismID", geneID = "geneID") {
  df %>%
    tidyr::drop_na(.data$geneID) %>%
    tidyr::separate_rows(.data$pfamID, sep = ";") %>%
    tidyr::separate_rows(.data$pfamID, sep = ",") %>%
    dplyr::filter(.data$pfamID != "") %>%
    dplyr::mutate(total_id = dplyr::n()) %>% # total number of IDs
    dplyr::group_by(.data$pfamID, .data$total_id,.data$organismID) %>%
    dplyr::distinct(.data$geneID) %>%
    dplyr::mutate(id_count = dplyr::n()) %>% # Count of each ID
    dplyr::mutate(p_id = (.data$id_count/.data$total_id))%>% # Relative abundance of each ID
    dplyr::ungroup() %>%
    dplyr::select(.data$pfamID, .data$organismID, .data$p_id) %>%
    dplyr::distinct()

}
