## code to prepare TolRad_model dataset goes here


TolRad_model <- readRDS("/Users/philipsweet/Google Drive/2022/Stats Portfolio/Project/Version3/Models/TolRad_Dec13A.rds")

TolRad_model$finalModel$xNames -> TolRad_ids

path_test <- c("inst/extdata")

## Alt Names for Pfam IDs

read.csv(file = "~/Google Drive/2022/Stats Portfolio/Project/Version3/datasets/MetaGenome/pfam_convert.csv") -> pfam_key

as.data.frame(TolRad_ids) %>%
left_join(pfam_key, by = c("TolRad_ids" = "Pfam_ID" ))-> TolRad_Pfam

usethis::use_data(TolRad_model, path_test, TolRad_Pfam, test_files, internal = TRUE, overwrite = TRUE)

path2 <- c("/Users/philipsweet/Google Drive/2022/Stats Portfolio/Project/Version3/datasets/Human_Gut/UniProt")

test_files <- list.files(path = path_test,
                         pattern = "*.xlsx",
                         full.names = TRUE

